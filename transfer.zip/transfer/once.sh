#!/bin/bash

localpath=/data/plots
remoteip=
remotepath=

for (( c=1; c<=$1; c++ ))
do
  sh transfer.sh ${localpath} root@${remoteip}:${remotepath}
done
