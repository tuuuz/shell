src=$1
dst=$2
status=`ps -ef | grep  "rsync" | wc -l`
#status=1
if [ $status ] && [ $status -gt 1 ] ;then
        echo "$(date +%Y-%m-%d\ %H:%M:%S) $src is working ,now waiting"
        exit;
fi 
#filename=$(ls -tr $src/*.plot 2>/dev/null | head -n 1 2>/dev/null)
filename=$(find $src -name "*.plot" -not -empty -exec ls {} \; 2>/dev/null | head -n 1 2>/dev/nul)
if [ -z $filename ] ;then 
        exit;
fi

echo "$(date +%Y-%m-%d\ %H:%M:%S) now  start moving $filename to $dst"
rsync -a "$filename" "$dst"  --progress --remove-source-files