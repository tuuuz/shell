#!/bin/bash

localpath=/data/plots
remoteip=
remotepath=

while [ ! -f /root/stoprun ]
do
  sh transfer.sh ${localpath} root@${remoteip}:${remotepath}
done
rm -f /root/stoprun
echo Stopfile found, exiting
